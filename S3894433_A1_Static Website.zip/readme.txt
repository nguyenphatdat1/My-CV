I intend to create an internet bookshop. I'll need to start by making a static website version so I can solicit input from your friends. In this stage, I need to create four pages.

-Front page
The Home page is divided into these three primary sections.

-Header: a nav bar and an image of the company logo. Every page has the same header.

-Footer: a second navigation bar. Every page has the same footer.

-Main: include numerous categories (at least two). At least three books are included in each category, as well as the category name as a link. The Category page will be opened by clicking on the category name. Link to the Book Detail page from each book's title and cover.
-Category page
The header and footer on the Category page are identical to those on the Home page.

Display at least three sub-categories under the main content. Each subcategory's name contains a link. Each subcategory should have at least three books displayed. Similar to how you display the Home page, display books. The sub-category names' "href" attribute can be set to "#."
-Book description page
The header and footer on the Book detail page are identical to those on the Home page.

Display a Breadcrumb at the top of the main content initially. The Home and Category names are two links in this breadcrumb, but the book name is just plain text. The Home page will appear when you click on it. The Category page will open when you click on the Category name.

Display three little and one huge image for the book. The book's price and a "Add to cart" button should then be visible. With the button, you are not required to do any action.

The book title (header text) and book description are located at the bottom of the page (paragraph).
-Message page
The Home page's header and footer are also present on the Contact page.

Display the header "Contact Us" at the top of the main text first.

The contact form is located below the heading and includes the following fields:

A drop-down box with the choices "I want to buy books" or "I want to sell books" serves as the contact information (use short text for the value attribute)
text is your name.
Your email address is:
Using your phone:
Contact information: "By phone" and "By email" checkboxes
Want to subscribe to our weekly newsletter? "Yes" and "No" radios. By default, the "Yes" radio is selected.
Observation: textarea field
There are two buttons at the bottom of the form: submit and reset.
Link to the website
https://nguyenphatdat1.github.io/My-CV/