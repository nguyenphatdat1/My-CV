I'm going to create an online resume website. The following pages make up this website:

-CV (My experience, education, awards, etc.)

-Projects (what I have done or are doing that may impress potential employers)

-Please get in touch (this is where people can contact me)

-Blog (this is my personal blog, all my written articles are positioned here)
*URL of my personal website:
